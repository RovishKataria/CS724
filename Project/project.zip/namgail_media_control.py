import pygame  # For basic playback functions; adjust if using another media library

# Initialize pygame mixer
pygame.mixer.init()

# Playlist (update with actual file paths)
playlist = ["/home/gesture/project0/SoundHelix-Song-1.mp3",
            "/home/gesture/project0/song2.mp3",
            "/home/gesture/project0/song3.mp3",
            "/home/gesture/project0/song4.mp3",
            "/home/gesture/project0/song5.mp3",
            "/home/gesture/project0/Mere Dholna.mp3",
            ]
current_song_index = 0

# Load song function
def load_song(index):
    global current_song_index
    current_song_index = index % len(playlist)
    pygame.mixer.music.load(playlist[current_song_index])

# Media control functions
def play_music():
    if not pygame.mixer.music.get_busy():
        load_song(current_song_index)
        pygame.mixer.music.play()

def pause_music():
    if pygame.mixer.music.get_busy():
        pygame.mixer.music.pause()

def resume_music():
    if not pygame.mixer.music.get_busy():
        pygame.mixer.music.unpause()

def stop_music():
    pygame.mixer.music.stop()

def next_song():
    global current_song_index
    current_song_index = (current_song_index + 1) % len(playlist)
    load_song(current_song_index)
    pygame.mixer.music.play()

def previous_song():
    global current_song_index
    current_song_index = (current_song_index - 1) % len(playlist)
    load_song(current_song_index)
    pygame.mixer.music.play()
