import cv2
import time
import mediapipe as mp

# Setup for Mediapipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

# Zoom variables
zoom_scale = 1.0  # Initial zoom level
zoom_step = 0.1   # Amount to zoom in/out

def zoom(frame, zoom_scale):
    h, w, _ = frame.shape
    center_x, center_y = w // 2, h // 2

    # Calculate the region to zoom into
    new_w, new_h = int(w / zoom_scale), int(h / zoom_scale)
    x1, y1 = center_x - new_w // 2, center_y - new_h // 2
    x2, y2 = center_x + new_w // 2, center_y + new_h // 2

    # Crop and resize the image for zooming effect
    frame = frame[y1:y2, x1:x2]
    frame = cv2.resize(frame, (w, h))

    return frame

def main():
    c = 0
    final_id = [0, 0, 0, 0, 0]
    global zoom_scale

    # Open camera
    cap = cv2.VideoCapture(0)  # Change to 0 or other index if needed
    if not cap.isOpened():
        print("Error: Could not open camera")
        return
    print("Camera activated")

    while True:
        ret, frame = cap.read()
        
        # Check if the frame is successfully captured
        if ret and frame is not None:
            img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(img_rgb)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    # Detect thumb and index finger positions
                    thumb_tip = hand_landmarks.landmark[4]
                    index_tip = hand_landmarks.landmark[8]

                    # Calculate distance between thumb and index finger
                    thumb_index_dist = ((index_tip.x - thumb_tip.x) ** 2 + (index_tip.y - thumb_tip.y) ** 2) ** 0.5

                    # Gesture-based zoom control (adjust these thresholds as needed)
                    if thumb_index_dist < 0.05:
                        zoom_scale = min(zoom_scale + zoom_step, 3.0)  # Zoom in
                    elif thumb_index_dist > 0.2:
                        zoom_scale = max(zoom_scale - zoom_step, 1.0)  # Zoom out

                    # Apply zoom to the frame
                    frame = zoom(frame, zoom_scale)

        # Add code here to save or process frames if needed

        # Exit condition (press 'q' to quit)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the camera
    cap.release()

if __name__ == "__main__":
    main()
