import cv2
import RPi.GPIO as GPIO
import time

# Servo motor setup
servo_pin = 17  # GPIO pin where the servo is connected
GPIO.setmode(GPIO.BCM)
GPIO.setup(servo_pin, GPIO.OUT)

# Initialize PWM for servo motor
servo = GPIO.PWM(servo_pin, 50)  # 50Hz frequency
servo.start(7.5)  # Initial position (90 degrees)

# Camera setup
cap = cv2.VideoCapture(0)  # 0 is for the default USB camera

# Function to move servo motor smoothly to a target angle
def move_servo_to_angle(current_angle, target_angle, step=1, delay=0.05):
    while current_angle != target_angle:
        if current_angle < target_angle:
            current_angle += step
            if current_angle > target_angle:
                current_angle = target_angle
        elif current_angle > target_angle:
            current_angle -= step
            if current_angle < target_angle:
                current_angle = target_angle

        # Convert angle (0 to 180) to duty cycle (2.5 to 12.5)
        duty_cycle = 2.5 + (current_angle / 18)
        servo.ChangeDutyCycle(duty_cycle)
        time.sleep(delay)  # Small delay to allow smooth movement
    return current_angle

# Variables for servo movement
current_angle = 90  # Start at center position
MIN_ANGLE = 0
MAX_ANGLE = 180

# Load Haar Cascade for human detection
human_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_fullbody.xml')

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture frame. Exiting...")
            break

        # Convert frame to grayscale for Haar cascade
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect humans in the frame
        humans = human_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(50, 50))

        if len(humans) > 0:
            # Get the first detected human's bounding box
            x, y, w, h = humans[0]
            human_center_x = x + w // 2  # Center of the detected human

            # Get the center of the frame
            frame_center_x = frame.shape[1] // 2

            # Calculate the offset between the human's position and the frame center
            offset = human_center_x - frame_center_x

            # Determine target angle based on offset
            if abs(offset) > 50:  # Only move if the offset is significant
                if offset < 0:  # Human is on the left
                    target_angle = current_angle - 5
                else:  # Human is on the right
                    target_angle = current_angle + 5

                # Clamp the target angle within valid servo range
                target_angle = max(MIN_ANGLE, min(MAX_ANGLE, target_angle))

                # Smoothly move servo to the target angle
                current_angle = move_servo_to_angle(current_angle, target_angle)

        # Display the frame with a bounding box for visualization
        for (x, y, w, h) in humans:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
        cv2.imshow("Human Detection", frame)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    print("Program interrupted by user.")

finally:
    # Clean up resources
    cap.release()
    cv2.destroyAllWindows()
    servo.stop()
    GPIO.cleanup()
