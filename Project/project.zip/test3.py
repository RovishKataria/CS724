import cv2

def find_video_devices():
    index = 0
    
    while True:
        cap = cv2.VideoCapture(index)
        if cap.isOpened():
            print(f"Device {index}: {cap.get(cv2.CAP_PROP_FPS)} fps")
            cap.release()
        else:
            break
        index += 2

if __name__ == "__main__":
    find_video_devices()
