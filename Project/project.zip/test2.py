'''import RPi.GPIO as GPIO
import time

# Set up GPIO
GPIO.setmode(GPIO.BCM)

# Pin configuration
TRIG_PIN = 17  # GPIO pin for Trigger
ECHO_PIN = 27  # GPIO pin for Echo

# Set up GPIO pins
GPIO.setup(TRIG_PIN, GPIO.OUT)
GPIO.setup(ECHO_PIN, GPIO.IN)

def get_distance():
    # Send a 10us pulse to TRIG pin to start the measurement
    GPIO.output(TRIG_PIN, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(TRIG_PIN, GPIO.LOW)

    # Wait for the echo pin to go HIGH, indicating pulse has been sent
    while GPIO.input(ECHO_PIN) == GPIO.LOW:
        pulse_start = time.time()

    # Wait for the echo pin to go LOW, indicating pulse has returned
    while GPIO.input(ECHO_PIN) == GPIO.HIGH:
        pulse_end = time.time()

    # Calculate pulse duration and distance (in cm)
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150  # Speed of sound is 34300 cm/s, divide by 2 for round-trip
    distance = round(distance, 2)  # Round to 2 decimal places
    print(distance)
    return distance

def detect_human_presence():
    # Get the distance from the sensor
    distance = get_distance()
    print(f"Distance: {distance} cm")

    # Define a threshold distance (e.g., 100 cm)
    threshold_distance = 100  # cm

    # Check if a human is detected within the threshold distance
    if distance < threshold_distance:
        print("Human detected!")
    else:
        print("No human detected.")

try:
    print("Starting human detection...")
    while True:
        detect_human_presence()
        time.sleep(1)  # Check every 1 second

except KeyboardInterrupt:
    print("\nExiting program")
    GPIO.cleanup()  # Clean up GPIO settings before exiting
'''
'''
import RPi.GPIO as GPIO  
import time  
GPIO.setmode(GPIO.BCM)  
GPIO_TRIG = 11  
GPIO_ECHO = 18 
GPIO.setup(GPIO_TRIG, GPIO.OUT)  
GPIO.setup(GPIO_ECHO, GPIO.IN)  
GPIO.output(GPIO_TRIG, GPIO.LOW)  
time.sleep(2)  
GPIO.output(GPIO_TRIG, GPIO.HIGH)  
time.sleep(0.00001)  
GPIO.output(GPIO_TRIG, GPIO.LOW) 
start_time = time.time()   
while GPIO.input(GPIO_ECHO)==0:  
    start_time = time.time()  
while GPIO.input(GPIO_ECHO)==1:  
    Bounce_back_time = time.time()  
    pulse_duration = Bounce_back_time - start_time  
    distance = round(pulse_duration * 17150, 2)  
    print ("Distance:",distance,"cm")  
GPIO.cleanup() 
'''
import RPi.GPIO as GPIO
import time
 
#GPIO Mode (BOARD / BCM)
GPIO.setmode(GPIO.BCM)
 
#set GPIO Pins
GPIO_TRIGGER = 18
GPIO_ECHO = 24
 
#set GPIO direction (IN / OUT)
GPIO.setup(GPIO_TRIGGER, GPIO.OUT)
GPIO.setup(GPIO_ECHO, GPIO.IN)
 
def distance():
    # set Trigger to HIGH
    GPIO.output(GPIO_TRIGGER, True)
 
    # set Trigger after 0.01ms to LOW
    time.sleep(0.00001)
    GPIO.output(GPIO_TRIGGER, False)
 
    StartTime = time.time()
    StopTime = time.time()
 
    # save StartTime
    while GPIO.input(GPIO_ECHO) == 0:
        StartTime = time.time()
 
    # save time of arrival
    while GPIO.input(GPIO_ECHO) == 1:
        StopTime = time.time()
 
    # time difference between start and arrival
    TimeElapsed = StopTime - StartTime
    # multiply with the sonic speed (34300 cm/s)
    # and divide by 2, because there and back
    distance = (TimeElapsed * 34300) / 2
 
    return distance
 
if __name__ == '__main__':
    try:
        while True:
            dist = distance()
            print ("Measured Distance = %.1f cm" % dist)
            time.sleep(1)
 
        # Reset by pressing CTRL + C
    except KeyboardInterrupt:
        print("Measurement stopped by User")
        GPIO.cleanup()