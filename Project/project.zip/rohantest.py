''' BUZZER
This code will cause the buzzer to beep intermittently. You can adjust the time.sleep() values for different beep patterns.
For more advanced uses, such as tone generation, you'll need to create a PWM signal to vary the frequency of the sound.
'''
# import RPi.GPIO as GPIO
# import time

# # Setup GPIO
# GPIO.setmode(GPIO.BCM)
# BUZZER_PIN = 27  # GPIO pin for buzzer

# GPIO.setup(BUZZER_PIN, GPIO.OUT)
# GPIO.output(BUZZER_PIN, GPIO.HIGH)  # Set to HIGH initially (buzzer off)

# # Function to trigger buzzer with low-level signal (active-low)
# def buzz_on():
#     GPIO.output(BUZZER_PIN, GPIO.LOW)  # LOW triggers the buzzer

# def buzz_off():
#     GPIO.output(BUZZER_PIN, GPIO.HIGH)  # HIGH turns the buzzer off

# # Example usage
# print("Triggering buzzer ON")
# buzz_on()  # Buzzer ON
# time.sleep(2)  # Buzzer will be ON for 2 seconds
# print("Turning buzzer OFF")
# buzz_off()  # Buzzer OFF

# # Cleanup
# GPIO.cleanup()

import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setup(27, GPIO.OUT)

# Turn on the buzzer
GPIO.output(27, GPIO.LOW)  # Buzzer ON
time.sleep(2)

# Turn off the buzzer
GPIO.output(27, GPIO.HIGH)  # Buzzer OFF
GPIO.cleanup()
