import speech_recognition as sr

# Initialize the recognizer
recognizer = sr.Recognizer()

# Set the device index for the Lenovo FHD Webcam microphone
device_index = 2  # Corresponds to the Lenovo FHD Webcam microphone

# Use the selected microphone
with sr.Microphone(device_index=device_index) as source:
    print("Adjusting for ambient noise... Please wait.")
    # Adjust for ambient noise to improve recognition accuracy
    recognizer.adjust_for_ambient_noise(source)
    print("Say something...")
    
    # Listen for audio from the microphone
    audio = recognizer.listen(source)

try:
    # Recognize speech using Google's speech recognition
    print("You said: " + recognizer.recognize_google(audio))
except sr.UnknownValueError:
    # Handle the case when speech is not recognized
    print("Sorry, I did not understand that.")
except sr.RequestError:
    # Handle the case when the service is unavailable
    print("Sorry, the service is down.")
