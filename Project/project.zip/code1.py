# Audio using webcam
'''
For direct testing, run below command in terminal:
arecord -D hw:3,0 -f cd test_audio.wav
press ctrl+c to stop

Replace input_device_index=1 with the correct device index for your webcam's microphone (you can find it with pyaudio.get_device_info_by_index()).
You can adjust the RECORD_SECONDS and RATE parameters to meet your requirements.

If the webcam microphone does not show up in arecord -l, ensure it is supported by your Raspberry Pi and check for drivers.
If audio quality is poor, adjust the RATE or use a noise-canceling library like webrtcvad.
'''
import os
import subprocess
from datetime import datetime
from pocketsphinx import LiveSpeech

# Function to capture photo
def capture_photo():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    photo_name = f"photo_{timestamp}.jpg"
    photo_path = os.path.join(os.getcwd(), photo_name)
    subprocess.run(["libcamera-still", "-o", photo_path])
    print(f"Photo saved as {photo_name}")

# Function to record video
def record_video(duration=5):  # Duration in seconds
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    video_name = f"video_{timestamp}.h264"
    video_path = os.path.join(os.getcwd(), video_name)
    subprocess.run(["libcamera-vid", "-o", video_path, "-t", str(duration * 1000)])
    print(f"Video saved as {video_name}")

# Voice recognition with PocketSphinx
speech = LiveSpeech(
    lm='7740.lm',        # Path to your language model
    dic='7740.dic',      # Path to your dictionary
    kws_threshold=1e-20  # Adjust for sensitivity
)

print("Listening for commands...")
for phrase in speech:
    print(f"Detected: {phrase.hypothesis()}")
    if 'capture photo' in phrase.hypothesis():
        print("Capture photo command recognized.")
        capture_photo()
    elif 'record video' in phrase.hypothesis():
        print("Record video command recognized.")
        record_video()

