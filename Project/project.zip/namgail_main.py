from namgail_gesture import detect_gestures_and_control_media

def main():
    detect_gestures_and_control_media()

if __name__ == "__main__":
    main()
