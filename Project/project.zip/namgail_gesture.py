import cv2
import time
import asyncio
import requests
import base64
import mediapipe as mp
import RPi.GPIO as GPIO
import pygame
import pyttsx3
import logging
from datetime import datetime

# Setup GPIO pins
GPIO.setmode(GPIO.BCM)
GPIO_TRIGGER = 18
GPIO_ECHO = 24
GPIO.setup(GPIO_TRIGGER, GPIO.OUT)
GPIO.setup(GPIO_ECHO, GPIO.IN)

# Initialize pygame mixer and text-to-speech engine
pygame.mixer.init()
engine = pyttsx3.init()

# Setup logging
logging.basicConfig(
    filename='gesture_control.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Define global variables
last_capture_time = 0
capture_interval = 3
is_recording = False
video_writer = None
frame = None
current_song_index = 0
is_playing = 0
playlist = [
    "/home/gesture/project0/SoundHelix-Song-1.mp3",
    "/home/gesture/project0/song2.mp3",
    "/home/gesture/project0/song3.mp3",
    "/home/gesture/project0/song4.mp3",
    "/home/gesture/project0/song5.mp3",
    "/home/gesture/project0/Mere Dholna.mp3",
]

# Define functions
def log_action(action):
    logging.info(f"Action performed: {action}")

def distance():
    GPIO.output(GPIO_TRIGGER, True)
    time.sleep(0.01)
    GPIO.output(GPIO_TRIGGER, False)
    StartTime = time.time()
    StopTime = time.time()
    while GPIO.input(GPIO_ECHO) == 0:
        StartTime = time.time()
    while GPIO.input(GPIO_ECHO) == 1:
        StopTime = time.time()
    TimeElapsed = StopTime - StartTime
    dist = (TimeElapsed * 34300) / 2
    return dist

def func_voice_warning(text):
    engine.say(text)
    engine.runAndWait()

def load_song(index):
    global current_song_index
    current_song_index = index % len(playlist)
    pygame.mixer.music.load(playlist[current_song_index])

def func_take_photo():
    global last_capture_time
    global frame
    current_time = time.time()
    if current_time - last_capture_time >= capture_interval:
        func_voice_warning("Capturing photo")
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        image_filename = f"captured_{timestamp}.png"
        cv2.imwrite(image_filename, frame)
        log_action(f"Captured photo: {image_filename}")
        last_capture_time = current_time

def func_take_photo_hdr():
    global last_capture_time
    global frame
    current_time = time.time()
    if current_time - last_capture_time >= capture_interval:
        func_voice_warning("Capturing HDR photo")
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        image_filename = f"hdr_captured_{timestamp}.png"
        hdr_image = cv2.detailEnhance(frame, sigma_s=12, sigma_r=0.15)
        cv2.imwrite(image_filename, hdr_image)
        log_action(f"Captured HDR photo: {image_filename}")
        last_capture_time = current_time

def func_start_video_capture():
    global video_writer
    global is_recording
    if not is_recording:
        func_voice_warning("Video recording on")
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        video_filename = f"video_{timestamp}.avi"
        video_writer = cv2.VideoWriter(video_filename, cv2.VideoWriter_fourcc(*'XVID'), 20.0, (640, 480))
        log_action(f"Recording started: {video_filename}")
        is_recording = True

def func_end_video_capture():
    global video_writer
    global is_recording
    if is_recording:
        func_voice_warning("Video recording off")
        log_action("Recording stopped")
        is_recording = False
        video_writer.release()
        video_writer = None

def func_music_play():
    global is_playing
    if not pygame.mixer.music.get_busy() and not is_playing:
        func_voice_warning("Music play")
        load_song(current_song_index)
        pygame.mixer.music.play()
        is_playing = 1
        log_action("Music started")

def func_music_simple_pause():
    global is_playing
    if pygame.mixer.music.get_busy() and is_playing:
        pygame.mixer.music.pause()
        is_playing = 0

def func_music_pause():
    if pygame.mixer.music.get_busy() and is_playing:
        func_music_simple_pause()
        func_voice_warning("Music paused")
        log_action("Music paused")

def func_music_resume():
    global is_playing
    if not pygame.mixer.music.get_busy():
        func_voice_warning("Music resumed")
        pygame.mixer.music.unpause()
        is_playing = 1
        log_action("Music resumed")

def func_music_next():
    global current_song_index
    global is_playing
    current_song_index = (current_song_index + 1) % len(playlist)
    func_music_simple_pause()
    func_voice_warning("Playing next music")
    load_song(current_song_index)
    pygame.mixer.music.play()
    is_playing = 1
    log_action("Playing next song")

def func_music_prev():
    global current_song_index
    global is_playing
    current_song_index = (current_song_index - 1) % len(playlist)
    func_music_simple_pause()
    func_voice_warning("Playing previous music")
    load_song(current_song_index)
    pygame.mixer.music.play()
    is_playing = 1
    log_action("Playing previous song")

def func_light_on():
    func_voice_warning("Light is turned on")
    log_action("Light turned on")

def func_light_off():
    func_voice_warning("Light is turned off")
    log_action("Light turned off")

def func_burst_photos():
    global last_capture_time
    global frame
    current_time = time.time()
    if current_time - last_capture_time >= capture_interval:
        func_voice_warning("Capturing burst photos")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        for i in range(3):
            image_filename = f"burst_{timestamp}_{i+1}.png"
            cv2.imwrite(image_filename, frame)
            log_action(f"Captured burst photo: {image_filename}")
            time.sleep(0.5)
        last_capture_time = current_time

def function_map(condition):
    if condition == '01100':
        func_take_photo()
    elif condition == '11001':
        func_take_photo_hdr()
    elif condition == '11000':
        func_start_video_capture()
    elif condition == '10000':
        func_end_video_capture()
    elif condition == '00001':
        func_music_play()
    elif condition == '00011':
        func_music_pause()
    elif condition == '00111':
        func_music_resume()
    elif condition == '01111':
        func_music_next()
    elif condition == '11111':
        func_music_prev()
    elif condition == '10101':
        func_light_on()
    elif condition == '10100':
        func_light_off()
    elif condition == '11100':
        func_burst_photos()

def cleanup():
    GPIO.cleanup()
    pygame.mixer.quit()
    func_voice_warning("Exiting program safely")
    log_action("Program terminated safely")

def main():
    global last_capture_time, frame
    frame_count = 0
    c = 0
    final_id = [0, 0, 0, 0, 0]
    prev_condition = "#####"
    last_time = time.time()
    while True:
        dist = distance()
        time.sleep(0.05)
        if dist < 50:
            cap = cv2.VideoCapture(0)
            print("Camera activated")
            c = 0
            final_id = [0, 0, 0, 0, 0]
            while dist < 50 or is_recording:
                ret, frame = cap.read()
                if not ret:
                    break
                # Process gestures here (unchanged from your existing implementation)
                dist = distance()
            if cap:
                cap.release()
                print("Camera deactivated")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Program interrupted by user.")
    except Exception as e:
        logging.error(f"Unexpected error: {str(e)}")
    finally:
        cleanup()
