import cv2
import time
import requests
import base64
import mediapipe as mp


def capture_photo(camera):
    camera.start_preview()
    time.sleep(2)  # Allow camera to adjust
    photo_path = 'photo.jpg'
    camera.capture(photo_path)
    camera.stop_preview()
    return photo_path


mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils
finger_names = {
    4: "Thumb",
    8: "Index Finger",
    12: "Middle Finger",
    16: "Ring Finger",
    20: "Pinky Finger"
}
id = '00000'

last_capture_time = 0
capture_interval = 3



def main():
    last_capture_time = 0
    capture_interval = 3
    is_recording = False
    video_writer = None
    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(img_rgb)
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                fingertip_ids = [4, 8, 12, 16, 20]

                c=0
                for tip_id in fingertip_ids :
                    landmark = hand_landmarks.landmark[tip_id]
                    if tip_id == 4 and (hand_landmarks.landmark[tip_id - 2].x > landmark.x)  :
                        c=c+1
                    if tip_id != 4 and landmark.y < hand_landmarks.landmark[tip_id - 2].y:
                        c=c+1
                    else :
                        c=c+0
                print(c)
                if c == 5 :
                    current_time = time.time()
                    if current_time -  last_capture_time >= capture_interval:
                        timestamp = time.strftime("%Y%m%d_%H%M%S")
                        image_filename = f"captured_{timestamp}.png"
                        cv2.imwrite(image_filename, frame)
                        print(f"Captured photo: {image_filename}")
                        last_capture_time = current_time
                elif c == 4 and not is_recording :
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    video_filename = f"video_{timestamp}.avi"
                    video_writer = cv2.VideoWriter(video_filename, cv2.VideoWriter_fourcc(*'XVID'), 20.0, (640, 480))
                    print(f"Recording started: {video_filename}")
                    is_recording = True
                elif c == 0 and is_recording :
                    print("Recording stopped. All fingers are down.")
                    is_recording = False
                    video_writer.release()  # Stop recording
                    video_writer = None
                if is_recording and video_writer is not None:
                    video_writer.write(frame)

            # Print finger tip information
                
                        





if __name__ == "__main__":
    main()