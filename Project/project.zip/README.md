camera module - p5v04a sunny
camera00 - Lenovo 300 FHD Webcam
camera 01 - HP webcam w300
Speaker - XSound GO
BreadBoard
Raspberry Pi
Buzzer - mh-fmd
Speaker Module - 
Lidar sensor - GY-302

# Rquirements
need a microphone module to detect voice commands.

Features of GY-302:
It measures light intensity in lux (lx), which corresponds to the brightness perceived by the human eye.
The BH1750 sensor can measure light in the range of 0.11 lx to 100,000 lx.
Communicates using the I2C protocol, which allows for simple integration with microcontrollers like Arduino, Raspberry Pi, or ESP32.

